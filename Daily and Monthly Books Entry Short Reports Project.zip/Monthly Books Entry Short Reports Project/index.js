let addBtn = document.getElementById('data_add_btn');

addBtn.addEventListener('click', function(para){
    para.preventDefault();

    let date = document.getElementById('date').value;
    let amount = document.getElementById('number').value;

    if(date == "" || amount == ""){
        alert('Please Fillup All Fields!');
    }else{
        let tBody = document.getElementById('tBody');
        let tr = document.createElement('tr');
        // for date colum start
        let td = document.createElement('td');
        td.innerHTML = date;
        tr.appendChild(td);
        // for date colum end
        // for amount colum start
        let td1 = document.createElement('td');
        td1.innerHTML = amount;
        tr.appendChild(td1);
        // for amount colum end
        tBody.appendChild(tr);
    }
});

// Only Single row and colum data show start

// addBtn.addEventListener('click', function(){
//     let date = document.getElementById('date').value;
//     let amount = document.getElementById('number').value;

//     document.getElementById('dateShow').innerHTML = date;
//     document.getElementById('b_a_Show').innerHTML = amount;
// });
// Only Single row and colum data show end